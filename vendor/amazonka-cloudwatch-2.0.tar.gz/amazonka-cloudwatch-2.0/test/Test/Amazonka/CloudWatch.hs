-- |
-- Module      : Test.Amazonka.CloudWatch
-- Copyright   : (c) 2013-2021 Brendan Hay
-- License     : Mozilla Public License, v. 2.0.
-- Maintainer  : Brendan Hay <brendan.g.hay+amazonka@gmail.com>
-- Stability   : auto-generated
-- Portability : non-portable (GHC extensions)
module Test.Amazonka.CloudWatch
  ( tests,
    fixtures,
  )
where

import Test.Tasty (TestTree)

tests :: [TestTree]
tests = []

fixtures :: [TestTree]
fixtures = []
